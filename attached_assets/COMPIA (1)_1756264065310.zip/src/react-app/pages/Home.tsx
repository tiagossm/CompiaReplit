import Dashboard from '@/react-app/pages/Dashboard';

export default function Home() {
  return <Dashboard />;
}
