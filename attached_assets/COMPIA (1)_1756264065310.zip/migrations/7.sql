
ALTER TABLE inspections ADD COLUMN inspector_signature TEXT;
ALTER TABLE inspections ADD COLUMN responsible_signature TEXT;
