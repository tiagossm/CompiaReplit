
ALTER TABLE inspections DROP COLUMN company_name;
ALTER TABLE inspections DROP COLUMN cep;
ALTER TABLE inspections DROP COLUMN address;
ALTER TABLE inspections DROP COLUMN latitude;
ALTER TABLE inspections DROP COLUMN longitude;
ALTER TABLE inspections DROP COLUMN action_plan;
