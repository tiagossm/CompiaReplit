
-- Rollback: This would require storing the original categories, 
-- but since we're organizing everything, we'll keep them organized
SELECT 'No rollback - templates organized into Security category' as message;
