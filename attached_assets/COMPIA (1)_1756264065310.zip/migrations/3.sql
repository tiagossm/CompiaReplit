
ALTER TABLE inspections ADD COLUMN company_name TEXT;
ALTER TABLE inspections ADD COLUMN cep TEXT;
ALTER TABLE inspections ADD COLUMN address TEXT;
ALTER TABLE inspections ADD COLUMN latitude REAL;
ALTER TABLE inspections ADD COLUMN longitude REAL;
ALTER TABLE inspections ADD COLUMN action_plan TEXT;
