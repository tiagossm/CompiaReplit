
DROP TABLE role_permissions;
