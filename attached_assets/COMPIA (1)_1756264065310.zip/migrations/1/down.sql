
DROP TABLE inspection_reports;
DROP TABLE inspection_items;
DROP TABLE inspections;
