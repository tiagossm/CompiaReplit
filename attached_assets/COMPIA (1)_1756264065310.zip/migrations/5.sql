
ALTER TABLE inspection_items ADD COLUMN ai_action_plan TEXT;
