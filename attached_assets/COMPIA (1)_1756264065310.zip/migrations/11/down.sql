
DELETE FROM organizations WHERE id = 1 AND name = 'IA SST Master';
