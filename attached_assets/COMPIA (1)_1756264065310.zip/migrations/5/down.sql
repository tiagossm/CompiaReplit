
ALTER TABLE inspection_items DROP COLUMN ai_action_plan;
