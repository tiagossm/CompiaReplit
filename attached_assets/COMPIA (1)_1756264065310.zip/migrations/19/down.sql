
DROP TABLE ai_assistants;
ALTER TABLE inspections DROP COLUMN ai_assistant_id;
