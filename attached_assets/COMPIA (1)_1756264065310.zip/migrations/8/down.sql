
DROP TABLE inspection_shares;
DROP TABLE inspection_collaborators;
DROP TABLE user_organizations;
DROP TABLE organizations;
DROP TABLE users;
