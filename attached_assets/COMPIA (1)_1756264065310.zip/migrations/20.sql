
ALTER TABLE inspections ADD COLUMN responsible_name TEXT;
