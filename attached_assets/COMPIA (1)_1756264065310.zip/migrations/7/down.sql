
ALTER TABLE inspections DROP COLUMN inspector_signature;
ALTER TABLE inspections DROP COLUMN responsible_signature;
