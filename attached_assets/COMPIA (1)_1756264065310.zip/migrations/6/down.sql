
ALTER TABLE inspections DROP COLUMN action_plan_type;
DROP TABLE action_items;
ALTER TABLE inspection_items DROP COLUMN ai_pre_analysis;
