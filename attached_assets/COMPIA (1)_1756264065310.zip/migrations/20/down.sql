
ALTER TABLE inspections DROP COLUMN responsible_name;
