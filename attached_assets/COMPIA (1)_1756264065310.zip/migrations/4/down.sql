
DROP TABLE inspection_media;
